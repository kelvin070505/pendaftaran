import React, { useState } from "react";

const packages = [
  { speed: "7 Mbps", price: "Rp 165.000" },
  { speed: "10 Mbps", price: "Rp 180.000" },
  { speed: "20 Mbps", price: "Rp 235.000" },
  { speed: "25 Mbps", price: "Rp 265.000" },
  { speed: "30 Mbps", price: "Rp 300.000" },
];

const features = [
  "Unlimited kuota (tanpa FUP)",
  "Jaringan stabil 24 jam",
  "Layanan teknis cepat dan responsif",
  "Gratis instalasi untuk pelanggan baru",
  "Bisa dipakai untuk belajar, kerja, gaming, dan streaming",
  "Dikelola langsung oleh warga lokal"
];

export default function RTRWNetLandingPage() {
  const [form, setForm] = useState({ nama: '', alamat: '', hp: '', paket: '' });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const mailto = `mailto:refspeednet@gmail.com?subject=Pendaftaran%20Internet%20RTRWNet&body=Nama: ${form.nama}%0D%0AAlamat: ${form.alamat}%0D%0AHP: ${form.hp}%0D%0APaket: ${form.paket}`;
    window.location.href = mailto;
  };

  return (
    <div style={{ minHeight: "100vh", backgroundImage: "url('/bg.jpg')", backgroundSize: "cover", padding: "2rem" }}>
      <div style={{ backdropFilter: "blur(8px)", backgroundColor: "rgba(255,255,255,0.7)", borderRadius: "1rem", padding: "1rem" }}>
        <h1 style={{ textAlign: "center", color: "#4f46e5", fontSize: "2rem", fontWeight: "bold" }}>REF SPEED NET</h1>
        <p style={{ textAlign: "center", color: "#374151", fontSize: "1.2rem", marginBottom: "1rem" }}>
          Internet Cepat dan Terjangkau untuk Warga Sekitar
        </p>

        <div style={{ display: "flex", flexWrap: "wrap", gap: "1rem", justifyContent: "center", marginBottom: "2rem" }}>
          {packages.map((pkg, idx) => (
            <div key={idx} style={{ border: "1px solid #ccc", borderRadius: "1rem", padding: "1rem", width: "200px", textAlign: "center", backgroundColor: "#fff" }}>
              <h2 style={{ color: "#4f46e5" }}>{pkg.speed}</h2>
              <p style={{ fontWeight: "bold" }}>{pkg.price} / bulan</p>
            </div>
          ))}
        </div>

        <ul style={{ maxWidth: "600px", margin: "0 auto 2rem", listStyle: "none", paddingLeft: 0 }}>
          {features.map((f, i) => (
            <li key={i} style={{ marginBottom: "0.5rem", display: "flex", alignItems: "center" }}>
              ✅ <span style={{ marginLeft: "0.5rem" }}>{f}</span>
            </li>
          ))}
        </ul>

        <form onSubmit={handleSubmit} style={{ maxWidth: "600px", margin: "0 auto", background: "#fff", padding: "1rem", borderRadius: "1rem" }}>
          <input type="text" name="nama" placeholder="Nama Lengkap" value={form.nama} onChange={handleChange} style={{ width: "100%", padding: "0.5rem", marginBottom: "1rem" }} />
          <input type="text" name="alamat" placeholder="Alamat Lengkap" value={form.alamat} onChange={handleChange} style={{ width: "100%", padding: "0.5rem", marginBottom: "1rem" }} />
          <input type="tel" name="hp" placeholder="Nomor HP" value={form.hp} onChange={handleChange} style={{ width: "100%", padding: "0.5rem", marginBottom: "1rem" }} />
          <select name="paket" value={form.paket} onChange={handleChange} style={{ width: "100%", padding: "0.5rem", marginBottom: "1rem" }}>
            <option value="">Pilih Paket</option>
            {packages.map((pkg, idx) => (
              <option key={idx} value={`${pkg.speed} - ${pkg.price}`}>{pkg.speed} - {pkg.price}</option>
            ))}
          </select>
          <button type="submit" style={{ width: "100%", padding: "0.75rem", backgroundColor: "#4f46e5", color: "#fff", border: "none", borderRadius: "0.5rem" }}>
            Kirim Pendaftaran
          </button>
        </form>

        <div style={{ textAlign: "center", marginTop: "2rem" }}>
          <p>Hubungi kami melalui WhatsApp:</p>
          <a href="https://wa.me/6282161740972" target="_blank" rel="noopener noreferrer" style={{ color: "#4f46e5", fontWeight: "bold" }}>
            0821-6174-0972
          </a>
        </div>
      </div>
    </div>
  );
}